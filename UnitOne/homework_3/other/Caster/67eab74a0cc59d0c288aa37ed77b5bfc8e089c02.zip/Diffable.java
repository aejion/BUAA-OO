public interface Diffable {
    String getDiff();
}
