public class Medium {
    private String line;
    private int termSign;

    public String getLine() {
        return line;
    }

    public int getTermSign() {
        return termSign;
    }

    public void setLine(String line) {
        this.line = line;
    }

    public void setTermSign(int termSign) {
        this.termSign = termSign;
    }
}
