package me;

public interface Index {
    String diff();

    String print();
}
