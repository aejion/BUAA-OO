interface Factor {
    String derivation();

    String toString();
}
